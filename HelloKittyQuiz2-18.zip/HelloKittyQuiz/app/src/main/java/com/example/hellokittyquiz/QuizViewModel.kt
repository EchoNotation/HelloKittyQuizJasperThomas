package com.example.hellokittyquiz

import android.util.Log
import androidx.lifecycle.ViewModel

class QuizViewModel : ViewModel() {

    private val TAG = "QuizViewModel"
    private var index = 0
    private var numCorrectAnswers = 0
    private var numQuestionsLeft = 4 //This should ideally pull from questions.size in MainActivity.kt
    private var questionsAnswered = BooleanArray(numQuestionsLeft)

    init {
        Log.d(TAG, "ViewModel instance created")
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "ViewModel instance destroyed")
    }

    public fun getIndex() : Int {
        return index
    }

    public fun getNumCorrectAnswers() : Int {
        return numCorrectAnswers
    }

    public fun getQuestionsAnswered() : BooleanArray {
        return questionsAnswered
    }

    public fun getNumQuestionsLeft() : Int {
        return numQuestionsLeft
    }

    public fun setIndex(index : Int) {
        this.index = index
    }

    public fun setNumCorrectAnswers(numCorrect : Int) {
        this.numCorrectAnswers = numCorrect
    }

    public fun setQuestionsAnswered(answered : BooleanArray) {
        this.questionsAnswered = answered
    }

    public fun setNumQuestionsLeft(numLeft : Int) {
        this.numQuestionsLeft = numLeft
    }
}